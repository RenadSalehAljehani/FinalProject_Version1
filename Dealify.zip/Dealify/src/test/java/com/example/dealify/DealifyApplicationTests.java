package com.example.dealify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealifyApplicationTests {

    @Test
    void contextLoads() {
    }

}
