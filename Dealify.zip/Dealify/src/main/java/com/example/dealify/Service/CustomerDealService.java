package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.DealJoinInDTO;
import com.example.dealify.Model.CustomerDeal;
import com.example.dealify.Model.CustomerProfile;
import com.example.dealify.Model.Deal;
import com.example.dealify.Repository.CustomerDealRepository;
import com.example.dealify.Repository.DealRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class CustomerDealService {

    private final CustomerDealRepository customerDealRepository;
    private final DealRepository dealRepository;

    //Waleed
    public void joinDeal(CustomerProfile customerProfile,DealJoinInDTO dealJoinInDTO,Integer dealId){
        Deal deal=dealRepository.findDealById(dealId);
        if (deal==null)throw new ApiException("Deal not found");

        if (Objects.equals(deal.getCurrentParticipants(), deal.getParticipantsLimit())){
            throw new ApiException("Deal participants limit has been reached");
        }

        CustomerDeal customerDeal=new CustomerDeal();
        customerDeal.setCustomer(customerProfile);
        customerDeal.setDeal(deal);

        Double discount=calculateDiscount(deal);
        customerDeal.setQuantity(dealJoinInDTO.getQuantity());
        customerDeal.setOriginalPrice(deal.getProduct().getPrice()*customerDeal.getQuantity());
        customerDeal.setDiscountedPrice(customerDeal.getOriginalPrice()-(customerDeal.getOriginalPrice()*discount));
        customerDeal.setJoinedAt(LocalDateTime.now());

        customerDealRepository.save(customerDeal);
        deal.setCurrentParticipants(deal.getCurrentParticipants()+1);
        deal.setQuantity(deal.getQuantity()+dealJoinInDTO.getQuantity());
        dealRepository.save(deal);
    }

    //Waleed
    public void updateQuantity(CustomerProfile customerProfile,Integer customerDealId,DealJoinInDTO dealJoinInDTO){

        CustomerDeal customerDeal=customerDealRepository.findCustomerDealById(customerDealId);
        if (customerDeal==null) throw new ApiException("Couldn't find deal joining details");

        if (!customerDeal.getCustomer().equals(customerProfile))
            throw new ApiException("Unauthorized to update another customer's quantity");

        Deal deal=dealRepository.findDealById(customerDeal.getDeal().getId());
        deal.setQuantity(deal.getQuantity()-customerDeal.getQuantity());
        customerDeal.setQuantity(dealJoinInDTO.getQuantity());
        customerDeal.setOriginalPrice(deal.getProduct().getPrice()*customerDeal.getQuantity());
        customerDeal.setDiscountedPrice(customerDeal.getOriginalPrice()-(customerDeal.getOriginalPrice()*calculateDiscount(deal)));

        customerDealRepository.save(customerDeal);

        deal.setQuantity(deal.getQuantity()+customerDeal.getQuantity());
    }

    //Waleed
    public void leaveDeal(CustomerProfile customerProfile,Integer customerDealId){
        CustomerDeal customerDeal=customerDealRepository.findCustomerDealById(customerDealId);
        if (customerDeal==null) throw new ApiException("Couldn't find deal joining details");

        if (!customerDeal.getCustomer().equals(customerProfile)) throw new ApiException("Unauthorized to do this action");

        Deal deal=dealRepository.findDealById(customerDeal.getDeal().getId());

        if (deal.getCurrentParticipants()==1){
            customerDealRepository.delete(customerDeal);
            dealRepository.delete(deal);
        }

        if (deal.getCreator().equals(customerProfile)){
            deal.setCreator(customerDealRepository.findCustomerDealsByDealAndJoinedAtAfterOrderByJoinedAtAsc(deal,customerDeal.getJoinedAt()).getFirst().getCustomer());
        }

        deal.setQuantity(deal.getQuantity()-customerDeal.getQuantity());
        deal.setCurrentParticipants(deal.getCurrentParticipants()-1);
        customerDealRepository.delete(customerDeal);
        dealRepository.save(deal);
    }

    private Double calculateDiscount(Deal deal) {
        return switch (deal.getParticipantsLimit()) {
            case 3 -> 0.5;
            case 5 -> 0.10;
            case 10 -> 0.15;
            case 15 -> 0.20;
            case 20 -> 0.25;
            default -> 0.0;
        };
    }

}
