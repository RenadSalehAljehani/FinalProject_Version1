package com.example.dealify.InDTO;

import com.example.dealify.Model.Category;
import com.example.dealify.Model.Image;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.awt.*;

@Setter
@Getter
@AllArgsConstructor
public class ProductInDTO {
    @NotEmpty(message = "Name is required.")
    @Size(max = 15, message = "Name can't exceed 15 characters.")
    private String name;

    @NotEmpty(message = "Description is required.")
    @Size(max = 800, message = "Description can't exceed 800 characters.")
    private String description;

    @NotNull(message = "Price is required.")
    @Positive(message = "Price must be a positive number.")
    private Double price;

    @NotNull(message = "Stock is required.")
    @Positive(message = "Stock must be a positive number.")
    private Integer stock;

    private Category category;

    private Image image;
}