package com.example.dealify.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class CustomerDeal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Integer id;

    @Column(columnDefinition = "int not null")
    private Integer quantity;

    @Column(columnDefinition = "double not null")
    private Double originalPrice;

    @Column(columnDefinition = "double not null")
    private Double discountedPrice;

    @CreationTimestamp
    @Column(columnDefinition = "timestamp not null")
    private LocalDateTime joinedAt;

    @Column(columnDefinition = "timestamp")
    private LocalDateTime updatedAt;

    @ManyToOne
    private CustomerProfile customer;

    @ManyToOne
    private Deal deal;
}
