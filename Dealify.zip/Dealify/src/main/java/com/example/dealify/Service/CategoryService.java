package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.Model.Category;
import com.example.dealify.OutDTO.CategoryOutDTO;
import com.example.dealify.Repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService { //Renad

    // 1. Declare a dependency for CategoryRepository using Dependency Injection
    private final CategoryRepository categoryRepository;

    // 2. CRUD
    // 2.1 Get
    public List<CategoryOutDTO> getAllCategories() {
        List<Category> categories = categoryRepository.findAll();
        List<CategoryOutDTO> categoryOutDTOS = new ArrayList<>();
        for (Category category : categories) {
            CategoryOutDTO categoryOutDTO = new CategoryOutDTO(category.getName());
            categoryOutDTOS.add(categoryOutDTO);
        }
        return categoryOutDTOS;
    }

    // 2.2 Post
    public void addCategory(Category category) {
        categoryRepository.save(category);
    }

    // 2.3 Update
    public void updateCategory(Integer id, Category category) {
        Category oldCategory = categoryRepository.findCategoryById(id);
        if (oldCategory == null) {
            throw new ApiException("Category Not Found.");
        }
        oldCategory.setName(category.getName());
        categoryRepository.save(oldCategory);
    }

    // 2.4 Delete
    public void deleteCategory(Integer id) {
        Category oldCategory = categoryRepository.findCategoryById(id);
        if (oldCategory == null) {
            throw new ApiException("Category Not Found.");
        }
        categoryRepository.delete(oldCategory);
    }

    // 3. Extra endpoint
    // An endpoint to get category by name
    public CategoryOutDTO getCategoryByName(String name) {
        Category category = categoryRepository.findCategoryByName(name);
        CategoryOutDTO categoryOutDTO = new CategoryOutDTO(category.getName());
        if (categoryRepository.findCategoryByName(name) == null) {
            throw new ApiException("Category Not Found.");
        }
        return categoryOutDTO;
    }
}