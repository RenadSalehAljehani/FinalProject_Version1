package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.Model.Category;
import com.example.dealify.Repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService { //Renad

    // 1. Declare a dependency for CategoryRepository using Dependency Injection
    private final CategoryRepository categoryRepository;

    // 2. CRUD
    // 2.1 Get
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    // 2.2 Post
    public void addCategory(Category category) {
        categoryRepository.save(category);
    }

    // 2.3 Update
    public void updateCategory(Integer id, Category category) {
        Category oldCategory = categoryRepository.findCategoryById(id);
        if (oldCategory == null) {
            throw new ApiException("Category Not Found.");
        }
        oldCategory.setName(category.getName());
        categoryRepository.save(oldCategory);
    }

    // 2.4 Delete
    public void deleteCategory(Integer id) {
        Category oldCategory = categoryRepository.findCategoryById(id);
        if (oldCategory == null) {
            throw new ApiException("Category Not Found.");
        }
        categoryRepository.delete(oldCategory);
    }

    // 3. Extra endpoints
    // An endpoint to get category by name
    public Category getCategoryByName(String name) {
        Category category = categoryRepository.findCategoryByName(name);
        if (categoryRepository.findCategoryByName(name) == null) {
            throw new ApiException("Category Not Found.");
        }
        return category;
    }
}