package com.example.dealify.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ReturnRequest { //Renad
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(700) not null")
    private String comment;

    private Boolean status;

    private LocalDate createdAt;

    @ManyToOne
    @JsonIgnore
    private CustomerProfile customer;

    @ManyToOne
    @JsonIgnore
    private VendorProfile vendorProfile;

    @ManyToOne
    private Deal deal;

    @ManyToOne
    @JsonIgnore
    private Product product;
}