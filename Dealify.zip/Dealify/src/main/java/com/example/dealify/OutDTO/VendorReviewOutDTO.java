package com.example.dealify.OutDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class VendorReviewOutDTO {
    private Double overallRating;

    private Integer serviceRating;

    private Integer productQualityRating;

    private String name;

}
