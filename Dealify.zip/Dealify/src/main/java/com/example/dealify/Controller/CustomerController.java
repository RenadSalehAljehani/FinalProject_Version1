package com.example.dealify.Controller;


import com.example.dealify.Api.ApiResponse;
import com.example.dealify.InDTO.CustomerInDTO;
import com.example.dealify.Service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api/v1/customer")
@RestController
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;


    @PostMapping("/register")
    public ResponseEntity register(@RequestBody @Valid CustomerInDTO customerInDTO) {
        customerService.register(customerInDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponse("Customer register successful"));
    }

    @PutMapping("/update/{customerId}")
    public ResponseEntity updateCustomer(//@AuthenticationPrincipal MyUser myUser,
                                         @PathVariable Integer customerId,
                                         @RequestBody @Valid CustomerInDTO customerInDTO) {
        customerService.updateCustomer(customerId, customerInDTO);
        return ResponseEntity.status(200).body(new ApiResponse("Customer with ID: " + customerId + " has been updated successfully"));
    }

    @DeleteMapping("/delete/{customerId}")
    public ResponseEntity deleteCustomer(//@AuthenticationPrincipal MyUser myUser,
                                         @PathVariable Integer customerId) {
        customerService.deleteMyAccount(customerId);
        return ResponseEntity.status(200).body(new ApiResponse("Customer deleted successful"));
    }
}