package com.example.dealify.Controller;

import com.example.dealify.Api.ApiResponse;
import com.example.dealify.Model.CustomerReview;
import com.example.dealify.Service.CustomerReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customerReview")
@RequiredArgsConstructor
public class CustomerReviewController { //Renad

    // 1. Declare a dependency for CustomerReviewService using Dependency Injection
    private final CustomerReviewService customerReviewService;

    // 2. CRUD
    // 2.1 Get
    @GetMapping("/get")
    public ResponseEntity getAllCustomerReviews() {
        return ResponseEntity.status(200).body(customerReviewService.getAllCustomerReviews());
    }

    // 2.2 Post
    @PostMapping("/add")
    public ResponseEntity addCustomerReview(@RequestBody @Valid CustomerReview customerReview) {
        customerReviewService.addCustomerReview(customerReview);
        return ResponseEntity.status(200).body(new ApiResponse("New Customer Review Added."));
    }

    // 2.3 Update
    @PutMapping("/update/{id}")
    public ResponseEntity updateCustomerReview(@PathVariable Integer id, @RequestBody @Valid CustomerReview customerReview) {
        customerReviewService.updateCustomerReview(id, customerReview);
        return ResponseEntity.status(200).body(new ApiResponse("Customer Review Updated."));
    }

    // 2.4 Delete
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteCustomerReview(@PathVariable Integer id) {
        customerReviewService.deleteCustomerReview(id);
        return ResponseEntity.status(200).body(new ApiResponse("Customer Review Deleted."));
    }
}