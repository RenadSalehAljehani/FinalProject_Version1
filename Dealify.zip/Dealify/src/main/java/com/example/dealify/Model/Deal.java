package com.example.dealify.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Deal {//Waleed
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "int not null")
    private Integer currentParticipants;

    @Column(columnDefinition = "int not null")
    private Integer participantsLimit;

    @Column(columnDefinition = "varchar(9) not null")
    private String status;

    @Column(columnDefinition = "int not null")
    private Integer quantity;

    @Column(columnDefinition = "double not null")
    private Double originalPrice;

    @Column(columnDefinition = "double not null")
    private Double discountedPrice;

    @Column(columnDefinition = "timestamp not null")
    private LocalDateTime startedAt;

    @Column(columnDefinition = "timestamp not null")
    private LocalDateTime endsAt;

    @ManyToOne
    @JsonIgnore
    private Product product;

    @OneToMany(cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<ReturnRequest> returnRequests;

    @ManyToMany
    @JsonIgnore
    private Set<CustomerProfile> customers;
}