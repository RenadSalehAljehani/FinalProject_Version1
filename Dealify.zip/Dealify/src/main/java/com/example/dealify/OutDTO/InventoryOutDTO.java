package com.example.dealify.OutDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InventoryOutDTO { //Ebtehal
    private Integer availableQuantity;

    private Integer soldQuantity;
}
