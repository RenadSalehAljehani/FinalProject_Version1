package com.example.dealify.Service;

import com.example.dealify.Model.CustomerProfile;
import com.example.dealify.Repository.CustomerProfileRepository;
import com.example.dealify.Repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerProfileService {
    private final CustomerRepository customerRepository;
    private final CustomerProfileRepository customerProfileRepository;


    public List<CustomerProfile> getAll() {
        return customerProfileRepository.findAll();
    }
}


//    public void creatProfile( CustomerProfileDto customerProfileDto){
//
//        Customer customer=customerRepository.findCustomerById(customerProfileDto.getId());
//        if (customer==null){
//            throw new ApiException("customer not found");
//        }
//
//        CustomerProfile customerProfile = new CustomerProfile();
//        customerProfile.setId(customerProfileDto.getId());
//        customerProfile.getCustomer().getCustomerProfile();
