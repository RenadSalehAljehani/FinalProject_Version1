package com.example.dealify.Controller;

import com.example.dealify.Api.ApiResponse;
import com.example.dealify.InDTO.ProductInDTO;
import com.example.dealify.Service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/product")
@RequiredArgsConstructor
public class ProductController {

    // 1. Declare a dependency for ProductService using Dependency Injection
    private final ProductService productService;

    // 2. CRUD
    // 2.1 Get
    @GetMapping("/getAllProducts") //Renad
    public ResponseEntity getAllProducts() {
        return ResponseEntity.status(200).body(productService.getAllProducts());
    }

    // 2.2 Post
    @PostMapping("/add") //Renad
    public ResponseEntity addProduct(@RequestBody @Valid ProductInDTO productInDTO) {
        productService.addProduct(productInDTO);
        return ResponseEntity.status(200).body(new ApiResponse("New Product Added."));
    }

    // 2.3 Update
    @PutMapping("/update/productId/{productId}") //Renad
    public ResponseEntity updateProduct(@PathVariable Integer productId, @RequestBody @Valid ProductInDTO productInDTO) {
        productService.updateProduct(productId, productInDTO);
        return ResponseEntity.status(200).body(new ApiResponse("Product Updated."));
    }

    // 2.4 Delete
    @DeleteMapping("/delete/productId/{productId}") //Renad
    public ResponseEntity deleteCategory(@PathVariable Integer productId) {
        productService.deleteProduct(productId);
        return ResponseEntity.status(200).body(new ApiResponse("Product Deleted."));
    }

    // 3. Extra endpoint
    // Get all products by category
    @GetMapping("/getProductsByCategory/categoryName/{categoryName}") //Ebtehal
    public ResponseEntity getProductsByCategory(@PathVariable String categoryName) {
        return ResponseEntity.status(200).body(productService.getProductsByCategory(categoryName));
    }

    @GetMapping("/get-product-open-deals/{product-id}")
    public ResponseEntity getProductOpenDeals (@PathVariable(name = "product-id") Integer productId){
        return ResponseEntity.status(200).body(productService.viewProductOpenDeals(productId));
    }
}