package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.ProductInDTO;
import com.example.dealify.Model.Category;
import com.example.dealify.Model.Image;
import com.example.dealify.Model.Product;
import com.example.dealify.OutDTO.CategoryOutDTO;
import com.example.dealify.OutDTO.DealOutDTO;
import com.example.dealify.OutDTO.ProductOutDTO;
import com.example.dealify.Repository.CategoryRepository;
import com.example.dealify.Repository.ImageRepository;
import com.example.dealify.Repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class ProductService {

    // 1. Declare a dependency for ProductRepository & CategoryRepository using Dependency Injection
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final ImageRepository imageRepository;
    private final DealService dealService;

    // 2. CRUD
    // 2.1 Get
    public List<ProductOutDTO> getAllProducts() { //Renad
        List<Product> products = productRepository.findAll();
        List<ProductOutDTO> productOutDTOS = new ArrayList<>();

        for (Product product : products) {
            Category category = product.getCategory();
            CategoryOutDTO categoryOutDTO = new CategoryOutDTO(category.getName());
            ProductOutDTO productOutDTO = new ProductOutDTO(product.getName(), product.getDescription(), product.getPrice(), product.getStock(), categoryOutDTO, null, null);
            productOutDTOS.add(productOutDTO);
        }
        return productOutDTOS;
    }

    // 2.2 Post
    public void addProduct(ProductInDTO productInDTO) { //Renad
        // Step 1: Validate category existence
        Category category = categoryRepository.findCategoryById(productInDTO.getCategory().getId());
        if (category == null) {
            throw new ApiException("Category Not Found.");
        }

        // Step 2: Create and save the product without SKU
        Product product = new Product(null, productInDTO.getName(), productInDTO.getDescription(), productInDTO.getPrice(), productInDTO.getStock(), null, true, category, null, null, null, null, null);
        productRepository.save(product);

        // Step 3: Generate SKU with product ID
        String generatedSKU = generateSKU(product.getCategory().getName(), product.getName(), product.getId());

        // Step 4: Update product with SKU and save product
        product.setSKU(generatedSKU);
        productRepository.save(product);

        // Step 5: Add the initial image if provided (check for null image URL)
        if (productInDTO.getImage() != null && productInDTO.getImage().getImageUrl() != null) {
            Image image = new Image(
                    null,
                    productInDTO.getImage().getImageUrl(),
                    productInDTO.getImage().getDescription(),
                    product
            );
            imageRepository.save(image);
        }
    }

    // 2.3 Update
    public void updateProduct(Integer productId, ProductInDTO productInDTO) { //Renad
        // Step 1: Find the existing product by ID
        Product product = productRepository.findProductById(productId);

        if (product == null) {
            throw new ApiException("Product Not Found.");
        }

        // Step 2: Validate category existence
        Category category = null;
        if (productInDTO.getCategory() != null) {
            category = categoryRepository.findCategoryById(productInDTO.getCategory().getId());
            if (category == null) {
                throw new ApiException("Category Not Found.");
            }
        }

        // Step 3: Update product fields
        product.setName(productInDTO.getName());
        product.setDescription(productInDTO.getDescription());
        product.setPrice(productInDTO.getPrice());
        product.setStock(productInDTO.getStock());
        product.setCategory(category);

        // Step 4: Update the SKU if necessary (e.g., if category or name changed)
        if (category != null || productInDTO.getName() != null) {
            String updatedSKU = generateSKU(product.getCategory().getName(), product.getName(), product.getId());
            product.setSKU(updatedSKU);
        }

        // Step 5: Save the updated product
        productRepository.save(product);
    }

    // 2.4 Delete
    public void deleteProduct(Integer productId) { //Renad
        // Step 1: Find the existing product by ID
        Product product = productRepository.findProductById(productId);

        if (product == null) {
            throw new ApiException("Product Not Found.");
        }

        // Step 2: Delete the product
        productRepository.delete(product);
    }

    // Helper method to generate SKU for the product
    public String generateSKU(String categoryName, String productName, Integer productId) { //Renad
        // Abbreviate category and product name (first 3 uppercase characters)
        String categoryCode = categoryName.length() >= 3
                ? categoryName.substring(0, 3).toUpperCase()
                : categoryName.toUpperCase();
        String productCode = productName.length() >= 3
                ? productName.substring(0, 3).toUpperCase()
                : productName.toUpperCase();

        // Add a random 4-digit number for uniqueness
        int randomNumber = new Random().nextInt(9000) + 1000; // Range: 1000-9999

        // Combine into SKU
        return categoryCode + "-" + productCode + "-" + randomNumber;
    }

    // 3. Extra end point
    // Get all products by category
    public List<ProductOutDTO> getProductsByCategory(String categoryName) { //Ebtehal
        List<Product> products = productRepository.findProductsByCategoryName(categoryName);

        if (products.isEmpty()) {
            throw new ApiException("No Products Has Been Found For Category: " + categoryName);
        }

        List<ProductOutDTO> productOutDTOS = new ArrayList<>();
        for (Product product : products) {
            Category category = product.getCategory();
            CategoryOutDTO categoryOutDTO = new CategoryOutDTO(category.getName());
            ProductOutDTO productOutDTO = new ProductOutDTO(product.getName(), product.getDescription(), product.getPrice(), product.getStock(), categoryOutDTO, product.getImages(), product.getDeals());
            productOutDTOS.add(productOutDTO);
        }
        return productOutDTOS;
    }

    public List<DealOutDTO> viewProductOpenDeals(Integer productId) {
        return dealService.viewProductDeals(productId);
    }
}