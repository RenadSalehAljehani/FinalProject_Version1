package com.example.dealify.Service;

public class FavoriteService {
}
