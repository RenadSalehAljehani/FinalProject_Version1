package com.example.dealify.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CustomerReview { //Renad
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "int not null")
    private Integer rating;

    @Column(columnDefinition = "varchar(500) not null")
    private String comment;

    @Column(columnDefinition = "date not null")
    private LocalDate createdAt;

    @Column(columnDefinition = "timestamp")
    private LocalDate updatedAt;

    @ManyToOne
    @JsonIgnore
    private CustomerProfile customer;

    @ManyToOne
    @JsonIgnore
    private Vendor vendor;
}