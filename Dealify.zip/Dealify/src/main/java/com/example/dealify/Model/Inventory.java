package com.example.dealify.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Inventory { //Renad
    @Id
    private Integer id;

    @Column(columnDefinition = "int not null")
    private Integer availableQuantity;

    @Column(columnDefinition = "int not null")
    private Integer soldQuantity;



    private LocalDate updatedAt;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inventory")
    private Set<Product> products;

    @OneToOne
    @MapsId
    @JsonIgnore
    private VendorProfile vendorProfile;
}