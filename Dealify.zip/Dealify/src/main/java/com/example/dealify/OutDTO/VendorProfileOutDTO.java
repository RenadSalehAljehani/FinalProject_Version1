package com.example.dealify.OutDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
//for customer to get vendor by there city

public class VendorProfileOutDTO { //ebtehal
    private String name;
    private String phoneNumber;
    public VendorProfileOutDTO() {

    }
}