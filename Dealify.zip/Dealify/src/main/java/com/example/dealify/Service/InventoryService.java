package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.Model.Inventory;
import com.example.dealify.Repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService { //Renad

    // 1. Declare a dependency for InventoryRepository using Dependency Injection
    private final InventoryRepository inventoryRepository;

    // 2. CRUD
    // 2.1 Get
    public List<Inventory> getAllInventories() {
        return inventoryRepository.findAll();
    }

    // 2.2 Post
    public void addInventory(Inventory inventory) {
        inventoryRepository.save(inventory);
    }

    // 2.3 Update
    public void updateInventory(Integer id, Inventory inventory) {
        Inventory oldInventory = inventoryRepository.findInventoryById(id);
        if (oldInventory == null) {
            throw new ApiException("Inventory Not Found.");
        }
        //oldInventory.setProducts(category.getName());
        inventoryRepository.save(oldInventory);
    }

    // 2.4 Delete
    public void deleteInventory(Integer id) {
        Inventory oldInventory = inventoryRepository.findInventoryById(id);
        if (oldInventory == null) {
            throw new ApiException("Inventory Not Found.");
        }
        inventoryRepository.delete(oldInventory);
    }
}