package com.example.dealify.Repository;

import com.example.dealify.Model.CustomerDeal;
import com.example.dealify.Model.Deal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CustomerDealRepository extends JpaRepository<CustomerDeal,Integer> {

    CustomerDeal findCustomerDealById(Integer id);

    List<CustomerDeal> findCustomerDealsByDealAndJoinedAtAfterOrderByJoinedAtAsc(Deal deal, LocalDateTime localDateTime);
}
