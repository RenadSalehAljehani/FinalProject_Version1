package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.DealCreationInDTO;
import com.example.dealify.InDTO.DealJoinInDTO;
import com.example.dealify.Model.*;
import com.example.dealify.OutDTO.DealOutDTO;
import com.example.dealify.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DealService {//Waleed

    private final DealRepository dealRepository;
    private final ProductRepository productRepository;
    private final CustomerProfileRepository customerProfileRepository;
    private final VendorProfileRepository vendorProfileRepository;
    private final CustomerDealService customerDealService;

    public void createDeal(CustomerProfile customer, Integer productId, DealCreationInDTO dealDTO){

        Product product = productRepository.findProductById(productId);
        if (product==null) throw new ApiException("Product not found");

        Deal deal=new Deal();

        deal.setCreator(customer);
        deal.setParticipantsLimit(dealDTO.getParticipantsLimit());
        deal.setQuantity(0);
        deal.setProduct(product);
        deal.setStatus("open");
        deal.setStartedAt(LocalDateTime.now());
        deal.setEndsAt(LocalDateTime.now().plusDays(5));
        dealRepository.save(deal);

        customerDealService.joinDeal(customer,new DealJoinInDTO(deal.getQuantity()),deal.getId());
    }

    public List<DealOutDTO> viewProductDeals(Integer productId){
        Product product=productRepository.findProductById(productId);
        if (product==null) throw new ApiException("product not found");
        return convertDealsToDTO(dealRepository.findDealsByProductAndStatus(product,"open"));
    }

    public List<Deal> viewCustomerOpenedDeals(Integer id){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(id);
        if (customerProfile==null) throw new ApiException("Customer not found");

        return dealRepository.findDealsByCustomerAndOpen(customerProfile,"open");
    }

    public List<Deal> viewCustomerCompletedDeals(Integer id){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(id);
        if (customerProfile==null) throw new ApiException("Customer not found");

        return dealRepository.findDealsByCustomerAndCompleted(customerProfile,"completed");
    }

    public List<Deal> viewVendorsOpenDeals(Integer id){
        VendorProfile vendorProfile=vendorProfileRepository.findVendorProfileById(id);
        if (vendorProfile==null)throw new ApiException("Vendor not found");

        return dealRepository.findDealsByVendorAndOpen(vendorProfile.getId(),"open");
    }

    @Scheduled(fixedRate = 60000) //runs every minute and delete all expired open deals
    public void deleteExpiredDeals(){
        List<Deal> deals=dealRepository.findDealsByStatusAndEndsAtIsBetween("open",LocalDateTime.now().minusMinutes(1),LocalDateTime.now());

        for (Deal d:deals){
            if (d.getEndsAt().isBefore(LocalDateTime.now())&&d.getStatus().equalsIgnoreCase("open")){
                dealRepository.delete(d);
            }
        }
    }

    public List<DealOutDTO> convertDealsToDTO(Collection<Deal> deals){
        List<DealOutDTO> dealOutDTOS=new ArrayList<>();

        for (Deal d:deals){
            dealOutDTOS.add(new DealOutDTO(d.getCurrentParticipants(),d.getParticipantsLimit(),d.getStatus(),d.getQuantity(),d.getStartedAt(),d.getEndsAt()));
        }

        return dealOutDTOS;
    }


}
