package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.DealCreationInDTO;
import com.example.dealify.Model.Customer;
import com.example.dealify.Model.CustomerProfile;
import com.example.dealify.Model.Deal;
import com.example.dealify.Model.Product;
import com.example.dealify.Repository.CustomerRepository;
import com.example.dealify.Repository.DealRepository;
import com.example.dealify.Repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DealService {//Waleed

    private final DealRepository dealRepository;
    private final ProductRepository productRepository;

    public void createDeal(CustomerProfile customer, Integer productId, DealCreationInDTO dealDTO){

        Product product = productRepository.findProductById(productId);
        if (product==null) throw new ApiException("Product not found");

        Deal deal=new Deal();

        Double discount = switch (deal.getParticipantsLimit()) {
            case 3 -> 0.5;
            case 5 -> 0.10;
            case 10 -> 0.15;
            case 15 -> 0.20;
            case 20 -> 0.25;
            default -> 0.0;
        };

        deal.getCustomers().add(customer);
        deal.setOriginalPrice(product.getOriginalPrice()*deal.getQuantity());
        deal.setDiscountedPrice(deal.getOriginalPrice()-(deal.getDiscountedPrice()*discount));
        deal.setStartedAt(LocalDateTime.now());
        deal.setEndsAt(LocalDateTime.now().plusDays(5));

        dealRepository.save(deal);
    }

    public void updateQuantity(Integer id, Integer customerId, Integer quantity){
        Deal deal = dealRepository.findDealById(id);

        Double discount = switch (deal.getParticipantsLimit()) {
            case 3 -> 0.5;
            case 5 -> 0.10;
            case 10 -> 0.15;
            case 15 -> 0.20;
            case 20 -> 0.25;
            default -> 0.0;
        };

        if (discount==0.0) throw new ApiException("Participants limit can only be 3,5,10,15 or 20");

        deal.setQuantity(quantity);
        deal.setOriginalPrice(deal.getProduct().getOriginalPrice()*quantity);
        deal.setDiscountedPrice(deal.getOriginalPrice()-(deal.getDiscountedPrice()*discount));
        dealRepository.save(deal);
    }


//    public List<Deal> viewProductDeals(Integer productId){
//        Product product=productRepository.findProductById(productId);
//        if (product==null) throw new
//        return dealRepository.findDealsByProductAndStatus(product,"open");
//    }



//    public List<Deal> viewCustomerOpenedDeals(Integer id){
//        return dealRepository.findDealsByStatus("open");
//    }

//    public List<Deal> viewCustomerCompletedDeals(Integer id){
//        return dealRepository.findDealsByStatus("completed");
//    }

//    public List<Deal> viewVendorsOpenDeals(Integer id){
//        return dealRepository.
//    }


}
