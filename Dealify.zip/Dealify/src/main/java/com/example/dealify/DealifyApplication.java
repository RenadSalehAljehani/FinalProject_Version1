package com.example.dealify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealifyApplication {

    public static void main(String[] args) {
        SpringApplication.run(DealifyApplication.class, args);
    }

}
