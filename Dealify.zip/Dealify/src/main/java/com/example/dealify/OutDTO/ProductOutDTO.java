package com.example.dealify.OutDTO;

import com.example.dealify.Model.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Setter
@Getter
@AllArgsConstructor
public class ProductOutDTO { //Renad
    private String name;

    private String description;

    private Double price;

    private Integer stock;

    private CategoryOutDTO category;

    private Set<Image> images;

    private Set<Deal> deals;
}