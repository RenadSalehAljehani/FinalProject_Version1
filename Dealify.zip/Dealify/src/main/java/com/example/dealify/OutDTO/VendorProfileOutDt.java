package com.example.dealify.OutDTO;

import com.example.dealify.Model.VendorReview;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
public class VendorProfileOutDt { //Ebtehal
    String name;
    private String companyName;
    private String phoneNumber;
    private String city;
    private String foundmentalFile;
    private List<VendorReviewOutDTO> vendorReviews;
   // private List<ReturnRequestsOutDTO> returnRequests;
    private InventoryOutDTO inventory;
    private List<ProductOutDTO> products;

}
