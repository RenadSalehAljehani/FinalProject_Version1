package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.VendorProfileInDTO;
import com.example.dealify.Model.Vendor;
import com.example.dealify.Model.VendorProfile;
import com.example.dealify.OutDTO.VendorProfileOutDTO;
import com.example.dealify.Repository.AuthRepository;
import com.example.dealify.Repository.VendorProfileRepository;
import com.example.dealify.Repository.VendorRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor

public class VendorProfileService {
    private final VendorRepository vendorRepository;
    private final AuthRepository authRepository;
    private final VendorProfileRepository vendorProfileRepository;


    public List<VendorProfile> getAll() {
        return vendorProfileRepository.findAll();
    }


//    public void creatProfile(VendorProfileInDTO vendorProfileInDTO) {
//        Vendor vendor = vendorRepository.findVendorById(vendorProfileInDTO.getId());
//        if (vendor == null) {
//            throw new ApiException("vendor not found");
//        }
//
//        VendorProfile vendorProfile = new VendorProfile(null,vendorProfileInDTO.getName(),vendorProfileInDTO.getPhoneNumber(),vendorProfileInDTO.getCity()
//                ,vendorProfileInDTO.getFoundationFile(),vendorProfileInDTO.getCompanyRegister(),vendor,null,null,null);
//    }

//    public void updateVendorProfile(Integer vendorId, VendorProfileInDTO vendorProfileInDTO) {
//
//        Vendor vendor = vendorRepository.findVendorById(vendorId);
//        if (vendor == null) {
//            throw new ApiException("Vendor not found");
//        }
//
//        VendorProfile vendorProfile = vendorProfileRepository.findByVendorId(vendorId);
//        if (vendorProfile == null) {
//            throw new ApiException("Vendor profile not found");
//        }
//
//        vendorProfile.setName(vendorProfileInDTO.getName());
//        vendorProfile.setPhoneNumber(vendorProfileInDTO.getPhoneNumber());
//        vendorProfile.setCity(vendorProfileInDTO.getCity());
//        vendorProfile.setCompanyRegister(vendorProfileInDTO.getCompanyRegister());
//
//        vendorProfileRepository.save(vendorProfile);
//    }



    //endPoint get vendor by city
//    public List<VendorProfileOutDTO> getVendorByCity(String city) {
//        List<VendorProfile> vendorProfiles = vendorProfileRepository.findVendorProfileByCity(city);
//        if (vendorProfiles == null || vendorProfiles.isEmpty()) {
//            throw new ApiException("There is no vendor in that city");
//        }
//
//        List<VendorProfileOutDTO> vendorProfileOutDTOS = new ArrayList();
//        for (VendorProfile vendorProfile : vendorProfiles) {
//            VendorProfileOutDTO vendorProfileOutDTO = new VendorProfileOutDTO();
//            vendorProfileOutDTO.setName(vendorProfile.getName());
//            vendorProfileOutDTO.setPhoneNumber(vendorProfile.getPhoneNumber());
//            vendorProfileOutDTOS.add(vendorProfileOutDTO);
//        }
//        return vendorProfileOutDTOS;
//    }
}