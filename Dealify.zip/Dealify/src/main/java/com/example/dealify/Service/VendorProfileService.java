package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.VendorProfileInDTO;
import com.example.dealify.Model.*;
import com.example.dealify.OutDTO.*;
import com.example.dealify.Repository.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor

public class VendorProfileService {
    private final VendorRepository vendorRepository;
    private final AuthRepository authRepository;
    private final VendorProfileRepository vendorProfileRepository;
    private final VendorReviewRepository vendorReviewRepository;
    private final ProductRepository productRepository;

    public void creatProfile(VendorProfileInDTO vendorProfileInDTO) {
        Vendor vendor = vendorRepository.findVendorById(vendorProfileInDTO.getId());
        if (vendor == null) {
            throw new ApiException("vendor not found");
        }

        VendorProfile vendorProfile = new VendorProfile();
        vendorProfile.setCompanyName(vendorProfileInDTO.getCompanyName());
        vendorProfile.setFoundmentalFile(vendorProfileInDTO.getFoundmentalFile());
        vendorProfile.setCity(vendorProfileInDTO.getCity());
        vendorProfileRepository.save(vendorProfile);
    }

    public void updateVendorProfile(Integer vendorId, VendorProfileInDTO vendorProfileInDTO) {

        Vendor vendor = vendorRepository.findVendorById(vendorId);
        if (vendor == null) {
            throw new ApiException("Vendor not found");
        }

        VendorProfile vendorProfile = vendorProfileRepository.findVendorProfileById(vendorId);
        if (vendorProfile == null) {
            throw new ApiException("Vendor profile not found");
        }

        vendorProfile.setCompanyName(vendorProfileInDTO.getCompanyName());
        vendorProfile.setFoundmentalFile(vendorProfileInDTO.getFoundmentalFile());
        vendorProfile.setCity(vendorProfileInDTO.getCity());

        vendorProfileRepository.save(vendorProfile);
    }



    // End point for customer to get vendor by city
    public VendorProfileOutDTO getVendorProfileById(Integer vendorId) {
        // استرجاع بروفايل البائع من الريبو
        VendorProfile vendorProfile = vendorProfileRepository.findVendorProfileById(vendorId);
        if (vendorProfile == null) {
            throw new ApiException("Vendor profile not found");
        }

        // عرض اسم البائع
        String vendorName = vendorProfile.getVendor().getMyUser().getName();

        // استرجاع التقييمات المرتبطة بالبائع
        List<VendorReviewOutDTO> reviews = new ArrayList<>();
        List<VendorReview> vendorReviews = vendorReviewRepository.findVendorReviewsByVendorProfile(vendorProfile);
        for (VendorReview review : vendorReviews) {
            // استرجاع اسم العميل الذي ترك التقييم
            MyUser customer = authRepository.findMyUserById(review.getCustomer().getId());
            if (customer == null) {
                throw new ApiException("Customer not found for review");
            }
            String customerName = customer.getName();  // اسم العميل

            // إضافة التقييم إلى القائمة
            reviews.add(new VendorReviewOutDTO(
                    review.getOverallRating(),
                    review.getServiceRating(),
                    review.getProductQualityRating(),
                    customerName  // اسم العميل الذي ترك التقييم
            ));
        }

        // استرجاع المنتجات المرتبطة بالبائع
//        List<ProductOutCU> products = new ArrayList<>();
//        List<Product> vendorProducts = productRepository.findProductByVendorProfile(vendorProfile);
//        for (Product product : vendorProducts) {
//            Set<ImageOutDTO> images = new ArrayList();
//            for (ProductImage image : product.getImages()) {
//                images.add(new ImageOutDTO(image.getUrl()));
//            }
//            products.add(new ProductOutCU(
//                    product.getName(),
//                    product.getPrice(),
//                    product.getStock(),
//                    images
//            ));
//        }
//
//        return new VendorProfileOutDTO(
//                vendorName, // اسم البائع
//                vendorProfile.getCompanyName(),
//                vendorProfile.getPhoneNumber(),
//                vendorProfile.getCity(),
//                vendorProfile.getFoundmentalFile(),
//                reviews,
//                products
//        );
    }


}


