package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.Model.CustomerReview;
import com.example.dealify.Repository.CustomerReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerReviewService {  //Renad

    // 1. Declare a dependency for CustomerReviewRepository using Dependency Injection
    private final CustomerReviewRepository customerReviewRepository;

    // 2. CRUD
    // 2.1 Get
    public List<CustomerReview> getAllCustomerReviews() {
        return customerReviewRepository.findAll();
    }

    // 2.2 Post
    public void addCustomerReview(CustomerReview customerReview) {
        customerReviewRepository.save(customerReview);
    }

    // 2.3 Update
    public void updateCustomerReview(Integer id, CustomerReview customerReview) {
        CustomerReview oldCustomerReview = customerReviewRepository.findCustomerReviewById(id);
        if (oldCustomerReview == null) {
            throw new ApiException("Customer Review Not Found.");
        }
        oldCustomerReview.setRating(customerReview.getRating());
        oldCustomerReview.setComment(customerReview.getComment());
        customerReviewRepository.save(oldCustomerReview);
    }

    // 2.4 Delete
    public void deleteCustomerReview(Integer id) {
        CustomerReview oldCustomerReview = customerReviewRepository.findCustomerReviewById(id);
        if (oldCustomerReview == null) {
            throw new ApiException("Customer Review Not Found.");
        }
        customerReviewRepository.delete(oldCustomerReview);
    }
}