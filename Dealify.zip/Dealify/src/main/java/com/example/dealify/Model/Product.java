package com.example.dealify.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Product { //Renad
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(15) not null")
    private String name;

    @Column(columnDefinition = "varchar(800) not null")
    private String description;

    @Column(columnDefinition = "double not null")
    private Double originalPrice;

    @Column(columnDefinition = "double not null")
    private Double discountedPrice;

    @Column(columnDefinition = "int not null")
    private Integer quantity;

    private Boolean isAvailable;

    @ManyToOne
    @JsonIgnore
    private Category category;

    @ManyToOne
    @JsonIgnore
    private Inventory inventory;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "product")
    private Set<Deal> deals;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "product")
    private Set<Image> images;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "product")
    private Set<ReturnRequest> returnRequest;

    @ManyToMany
    @JsonIgnore
    private Set<Favorite>favorites;
}