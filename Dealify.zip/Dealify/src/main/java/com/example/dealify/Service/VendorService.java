package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.VendorInDTO;
import com.example.dealify.Model.MyUser;
import com.example.dealify.Model.Vendor;
import com.example.dealify.Repository.AuthRepository;
import com.example.dealify.Repository.VendorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VendorService {
    private final AuthRepository authRepository;
    private final VendorRepository vendorRepository;


    //register for new vendor
    public void register(VendorInDTO vendorInDTO){
        MyUser myUser=authRepository.findMyUserByUsername(vendorInDTO.getUsername());
        if (myUser!=null){
            throw new ApiException(" user already exist");
        }

        MyUser myUser1=new MyUser();
        myUser1.setName(vendorInDTO.getName());
        myUser1.setUsername(vendorInDTO.getUsername());
        myUser1.setEmail(vendorInDTO.getEmail());
        myUser1.setPassword(vendorInDTO.getPassword());
        myUser1.setRole("VENDOR");
        authRepository.save(myUser1);

        Vendor vendor=new Vendor();
        vendor.setCommercialRegistration(vendorInDTO.getCommercialRegistration());
        vendor.setPhoneNumber(vendorInDTO.getPhoneNumber());
        vendor.setMyUser(myUser1);

        vendorRepository.save(vendor);
    }

    public void updateVendor(Integer vendorId, VendorInDTO vendorInDTO){

        MyUser oldUser=authRepository.findMyUserById(vendorId);
        if (oldUser==null){
            throw new ApiException(" vendor not found");
        }

        oldUser.setName(vendorInDTO.getName());
        oldUser.setUsername(vendorInDTO.getUsername());
        oldUser.setEmail(vendorInDTO.getEmail());
        oldUser.setPassword((vendorInDTO.getPassword()));
        oldUser.getVendor().setPhoneNumber(vendorInDTO.getPhoneNumber());
        oldUser.getVendor().setCommercialRegistration(vendorInDTO.getCommercialRegistration());

        authRepository.save(oldUser);

    }

    public void deleteMyAccount(Integer vendorId){
        MyUser vendor=authRepository.findMyUserById(vendorId);
        if (vendor==null){
            throw new ApiException(" can not found this account");
        }
        authRepository.delete(vendor);
    }


    //end point to get all product that has a less than 5

    //send notification if stock has 0 product



}