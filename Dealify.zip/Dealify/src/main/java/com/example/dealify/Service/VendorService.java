package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.VendorInDTO;
import com.example.dealify.Model.MyUser;
import com.example.dealify.Model.Vendor;
import com.example.dealify.Repository.AuthRepository;
import com.example.dealify.Repository.VendorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VendorService {
    private final AuthRepository authRepository;
    private final VendorRepository vendorRepository;

    //register for new vendor
    public void register(VendorInDTO vendorInDTO){
        MyUser myUser=authRepository.findMyUserByUsername(vendorInDTO.getUsername());
        if (myUser!=null){
            throw new ApiException(" user already exist");
        }
        // اتحقق اذا كان عنده سجل تجاري قبل تسجيله في الموقع
        if (vendorInDTO.getFoundationFile()!=true) {
            throw new ApiException("Company register is required to register as a vendor");
        }

        MyUser myUser1=new MyUser();
        myUser1.setName(vendorInDTO.getName());
        myUser1.setUsername(vendorInDTO.getUsername());
        myUser1.setEmail(vendorInDTO.getEmail());
        myUser1.setPassword(new BCryptPasswordEncoder().encode(vendorInDTO.getPassword()));
        myUser1.setRole("VENDOR");
        authRepository.save(myUser1);

        Vendor vendor=new Vendor();
        vendor.setFoundationFile(vendorInDTO.getFoundationFile());
        vendor.setCompanyRegister(vendorInDTO.getCompanyRegister());
        vendor.setMyUser(myUser1);

        vendorRepository.save(vendor);
    }

    public void updateVendor(Integer vendorId, VendorInDTO vendorInDTO){

        MyUser oldUser=authRepository.findMyUserById(vendorId);
        if (oldUser==null){
            throw new ApiException(" vendor not found");
        }

        oldUser.setName(vendorInDTO.getName());
        oldUser.setUsername(vendorInDTO.getUsername());
        oldUser.setEmail(vendorInDTO.getEmail());
        oldUser.setPassword(new BCryptPasswordEncoder().encode(vendorInDTO.getPassword()));
        oldUser.getVendor().setFoundationFile(vendorInDTO.getFoundationFile());
        oldUser.getVendor().setCompanyRegister(vendorInDTO.getCompanyRegister());

        authRepository.save(oldUser);

    }

    public void deleteMyAccount(Integer vendorId){
        MyUser vendor=authRepository.findMyUserById(vendorId);
        if (vendor==null){
            throw new ApiException(" can not found this account");
        }
        authRepository.delete(vendor);
    }
    //end point to get all product that has a less than 5

    //send notification if stock has 0 product
}