package com.example.dealify.OutDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
// for customer to get vendor profile with specific information
public class ProductOutCU {
    private String name;
    private String description;
    private ImageOutDTO image;
}