package com.example.dealify.Controller;

import com.example.dealify.Api.ApiResponse;
import com.example.dealify.Model.Category;
import com.example.dealify.Model.Inventory;
import com.example.dealify.Service.CategoryService;
import com.example.dealify.Service.InventoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
public class InventoryController { //Renad

    // 1. Declare a dependency for InventoryService using Dependency Injection
    private final InventoryService inventoryService;

    // 2. CRUD
    // 2.1 Get
    @GetMapping("/get")
    public ResponseEntity getAllInventories() {
        return ResponseEntity.status(200).body(inventoryService.getAllInventories());
    }

    // 2.2 Post
    @PostMapping("/add")
    public ResponseEntity addInventory(@RequestBody @Valid Inventory inventory) {
        inventoryService.addInventory(inventory);
        return ResponseEntity.status(200).body(new ApiResponse("New Inventory Added."));
    }

    // 2.3 Update
    @PutMapping("/update/{id}")
    public ResponseEntity updateInventory(@PathVariable Integer id, @RequestBody @Valid Inventory inventory) {
        inventoryService.updateInventory(id, inventory);
        return ResponseEntity.status(200).body(new ApiResponse("Inventory Updated."));
    }

    // 2.4 Delete
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteInventory(@PathVariable Integer id) {
        inventoryService.deleteInventory(id);
        return ResponseEntity.status(200).body(new ApiResponse("Inventory Deleted."));
    }
}