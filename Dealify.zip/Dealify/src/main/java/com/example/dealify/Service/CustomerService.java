package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.CustomerInDTO;
import com.example.dealify.InDTO.DealCreationInDTO;
import com.example.dealify.InDTO.DealJoinInDTO;
import com.example.dealify.Model.Customer;
import com.example.dealify.Model.CustomerProfile;
import com.example.dealify.Model.MyUser;
import com.example.dealify.Repository.AuthRepository;
import com.example.dealify.Repository.CustomerProfileRepository;
import com.example.dealify.Repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final AuthRepository authRepository;
    private final CustomerRepository customerRepository;
    private final CustomerProfileRepository customerProfileRepository;
    private final DealService dealService;
    private final CustomerDealService customerDealService;


    //register for new vendor
    public void register(CustomerInDTO customerDTO) {
        MyUser myUser = authRepository.findMyUserByUsername(customerDTO.getUsername());
        if (myUser != null) {
            throw new ApiException(" user already exist");
        }

        MyUser myUser1 = new MyUser();
        myUser1.setName(customerDTO.getName());
        myUser1.setUsername(customerDTO.getUsername());
        myUser1.setEmail(customerDTO.getEmail());
        myUser1.setPassword((customerDTO.getPassword()));
        myUser1.setRole("CUSTOMER");
        authRepository.save(myUser1);


    }


    public void updateCustomer(Integer customerId, CustomerInDTO customerInDTO) {

        MyUser oldUser = authRepository.findMyUserById(customerId);
        if (oldUser == null) {
            throw new ApiException(" customer not found");
        }

        oldUser.setName(customerInDTO.getName());
        oldUser.setUsername(customerInDTO.getUsername());
        oldUser.setEmail(customerInDTO.getEmail());
        oldUser.setPassword((customerInDTO.getPassword()));

        authRepository.save(oldUser);


    }

    public void deleteMyAccount(Integer customerId) {
        MyUser vendor = authRepository.findMyUserById(customerId);
        if (vendor == null) {
            throw new ApiException(" can not found this account");
        }
        authRepository.delete(vendor);
    }

    //Waleed
    public void createADeal(Integer customerId, Integer productId, DealCreationInDTO dealCreationInDTO){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(customerId);
        if (customerProfile==null) throw new ApiException("customer not found");

        dealService.createDeal(customerProfile,productId,dealCreationInDTO);
    }

    //Waleed
    public void joinADeal(Integer customerId, Integer dealId, DealJoinInDTO dealJoinInDTO){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(customerId);
        if (customerProfile==null) throw new ApiException("customer not found");

        customerDealService.joinDeal(customerProfile,dealJoinInDTO,dealId);
    }

    //Waleed
    public void updateQuantity (Integer customerId,Integer customerDealId,DealJoinInDTO dealJoinInDTO){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(customerId);
        if (customerProfile==null) throw new ApiException("customer not found");

        customerDealService.updateQuantity(customerProfile,customerDealId,dealJoinInDTO);
    }

    //Waleed
    public void leaveADeal(Integer customerId,Integer customerDealId){
        CustomerProfile customerProfile=customerProfileRepository.findCustomerProfileById(customerId);
        if (customerProfile==null) throw new ApiException("customer not found");

        customerDealService.leaveDeal(customerProfile,customerDealId);
    }



}