package com.example.dealify.Service;

import com.example.dealify.Api.ApiException;
import com.example.dealify.InDTO.CustomerInDTO;
import com.example.dealify.Model.Customer;
import com.example.dealify.Model.MyUser;
import com.example.dealify.Repository.AuthRepository;
import com.example.dealify.Repository.CustomerRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CustomerService {

    private final AuthRepository authRepository;
    private final CustomerRepository customerRepository;


    //register for new vendor
    public void register(CustomerInDTO customerDTO) {
        MyUser myUser = authRepository.findMyUserByUsername(customerDTO.getUsername());
        if (myUser != null) {
            throw new ApiException(" user already exist");
        }

        MyUser myUser1 = new MyUser();
        myUser1.setName(customerDTO.getName());
        myUser1.setUsername(customerDTO.getUsername());
        myUser1.setEmail(customerDTO.getEmail());
        myUser1.setPassword(new BCryptPasswordEncoder().encode(customerDTO.getPassword()));
        myUser1.setRole("CUSTOMER");
        authRepository.save(myUser1);

        Customer customer = new Customer();
        customer.setPhoneNumber(customerDTO.getPhoneNumber());
        customer.setMyUser(myUser1);
        customerRepository.save(customer);

    }


    public void updateCustomer(Integer customerId, CustomerInDTO customerInDTO) {

        MyUser oldUser = authRepository.findMyUserById(customerId);
        if (oldUser == null) {
            throw new ApiException(" customer not found");
        }

        oldUser.setName(customerInDTO.getName());
        oldUser.setUsername(customerInDTO.getUsername());
        oldUser.setEmail(customerInDTO.getEmail());
        oldUser.setPassword(new BCryptPasswordEncoder().encode(customerInDTO.getPassword()));
        oldUser.getCustomer().setPhoneNumber(customerInDTO.getPhoneNumber());

        authRepository.save(oldUser);


    }

    public void deleteMyAccount(Integer customerId) {
        MyUser vendor = authRepository.findMyUserById(customerId);
        if (vendor == null) {
            throw new ApiException(" can not found this account");
        }
        authRepository.delete(vendor);
    }
}