package com.example.dealify.Controller;

import com.example.dealify.Api.ApiResponse;
import com.example.dealify.InDTO.VendorInDTO;
import com.example.dealify.Service.VendorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/vendor")
@RequiredArgsConstructor

public class VendorController {

    private final VendorService vendorService;


    @PostMapping("/register")
    public ResponseEntity register(@RequestBody @Valid VendorInDTO vendorDto) {
        vendorService.register(vendorDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponse("Customer register successful"));
    }

    @PutMapping("/update/{customerId}")
    public ResponseEntity updateCustomer(@PathVariable Integer customerId,
                                         @RequestBody @Valid VendorInDTO vendorInDto) {
        vendorService.updateVendor( customerId, vendorInDto);
        return ResponseEntity.status(200).body(new ApiResponse("Customer with ID: " + customerId + " has been updated successfully"));
    }

    @DeleteMapping("/delete/{customerId}")
    public ResponseEntity deleteCustomer(@PathVariable Integer vendorId) {
        vendorService.deleteMyAccount(vendorId);
        return ResponseEntity.status(200).body(new ApiResponse("Customer deleted successful"));
    }



}

